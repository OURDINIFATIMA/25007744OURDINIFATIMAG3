Les données préparées seront enregistrées ici pendant la séance d'examen. Ne rien ajouter avant l'analyse en séance.
