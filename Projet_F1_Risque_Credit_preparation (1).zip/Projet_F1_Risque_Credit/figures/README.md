Les trois graphiques interprétés seront produits pendant l'épreuve et enregistrés ici.
