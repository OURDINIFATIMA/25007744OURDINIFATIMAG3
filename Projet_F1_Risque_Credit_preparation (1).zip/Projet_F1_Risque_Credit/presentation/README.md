Déposer ici la présentation finale de six diapositives (PDF et PPTX) après l'épreuve.
