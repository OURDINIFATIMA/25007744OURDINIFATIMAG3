Créer le notebook `projet_F1.ipynb` pendant l'épreuve uniquement, en respectant les 10 sections imposées dans les consignes.
