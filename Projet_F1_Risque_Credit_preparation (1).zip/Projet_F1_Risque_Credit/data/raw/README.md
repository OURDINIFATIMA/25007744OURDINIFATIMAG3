# Données brutes

Télécharger le fichier original `german.data` depuis la page officielle UCI :
https://archive.ics.uci.edu/dataset/144/statlog%2Bgerman%2Bcredit%2Bdata

Placer le fichier dans ce dossier sans modifier son contenu.

Date d'extraction : À COMPLÉTER après téléchargement réel.
Nom du fichier : german.data
Source : UCI Machine Learning Repository — Statlog (German Credit Data), dataset 144.
